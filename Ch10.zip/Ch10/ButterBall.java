// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Shui
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
public class ButterBall extends Sphere implements Comparable<Object3D>,Meltable {

	public ButterBall(String _name, double _radius) {
		super(_name, Material.Butter, _radius);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Object3D convertToOtherShape() {
		// TODO Auto-generated method stub
	    double edge = Math.cbrt(this.getVolume());
        return new Cube(this.getName(), this.getMaterial(), edge);
	}

	@Override
	public int compareTo(Object3D o) {
		// TODO Auto-generated method stub
		 double diff = this.getSurface() - o.getSurface();
	        if (diff != 0)
	            return (int) Math.signum(diff);
	        return this.getName().compareTo(o.getName());

	}
	

}
