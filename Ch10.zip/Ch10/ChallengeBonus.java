
public class ChallengeBonus {
	public static void main(String[] args) {
		System.out.println("===== Challenge Bonus =====\n");
			Square sq = new Square("FaceOfCube", 5.0);
			Circle ci = new Circle("FaceOfSphere", 6.78);
			
			
		System.out.println("-- Shape2D --");
		System.out.println(sq);
		System.out.println(ci);
		System.out.println();
		
        // ใช้ Printable (interface)
       System.out.println("-- Printable --");
        Printable[] printables = { sq, ci };
        for (Printable p : printables) {
            p.printinfo();
            System.out.println("  Label: " + p.getlabel());
            System.out.println(" Compactness: " + p.getCompactness());
        }
        System.out.println();
 
     // -------------------------
        // 🔥 2D → 3D Conversion
        // -------------------------
        System.out.println("-- 2D → 3D Conversion --");

        Cube cube = sq.toCube(Object3D.Material.Gold);
        Sphere sphere = ci.toSphere(Object3D.Material.Gold);

        System.out.println("Cube from Square:");
        System.out.println(" Volume: " + cube.getVolume());
        System.out.println(" Surface Area: " + cube.getSurface());

        System.out.println("\nSphere from Circle:");
        System.out.println(" Volume: " + sphere.getVolume());
        System.out.println(" Surface Area: " + sphere.getSurface());

        // -------------------------
        // เชื่อม concept
        // -------------------------
        System.out.println("\n-- Concept Link --");
        System.out.println("Square = Face of Cube");
        System.out.println("Circle = Cross-section of Sphere");

        System.out.println("Square Area (face): " + sq.getArea());
        System.out.println("Cube Volume: " + cube.getVolume());

        System.out.println("Circle Area: " + ci.getArea());
        System.out.println("Sphere Volume: " + sphere.getVolume());
    }
		
		
	

}
