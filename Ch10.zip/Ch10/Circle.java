
public class Circle extends Shape2D implements Printable {
	private double radius;

	public Circle(String name, double radius) {
		super(name);
		this.radius = radius;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printinfo() {
		System.out.println("Circle: "+ name+ " Radius: "+ radius+", Area: "+ getArea());
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getlabel() {
		// TODO Auto-generated method stub
		return "CIR-" + name;
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return Math.PI* radius*radius;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return 2*Math.PI*radius;
	}
	
	public double getCompactness() {
        return getArea() / getPerimeter();
    }

    // 🔥 NEW: เชื่อม 2D → 3D
    public Sphere toSphere(Object3D.Material mat) {
        return new Sphere(name + "_Sphere", mat, radius);
    }

}
