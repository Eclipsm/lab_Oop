
// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Shui
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
public class Cube extends Object3D {
	private double edge;

	public Cube(String _name, Object3D.Material _matType,double _edge) {
		super(_name, _matType);
		this.edge = _edge;
		// TODO Auto-generated constructor stub
	}
	public double getEdge() {
		return this.edge;
	}
	
	
	public double getVolume() {
		return edge*edge*edge;
	}	//Calculate and return the volume of this object
	public double getSurface() {
		return 6 * (edge*edge);
		
	} //Calculate and return the surface area of this object

}
