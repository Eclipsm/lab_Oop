
public interface Printable {
	
	//show information
	public void printinfo();
	
	// Short name
	public String getlabel();
	
	double getCompactness();

}
