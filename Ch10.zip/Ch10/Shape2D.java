
public abstract class Shape2D {
	protected String name;
	
	public Shape2D(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public abstract double getArea();
	public abstract double getPerimeter();
	
	public double getDensityLikeMetric() {
        return getArea() / (getPerimeter() + 1);
    }
	
	
	public String toString() {
		return name + " [Area: "+  getArea() +" , Perimeter: " +getPerimeter()+ "]";
	}

}
