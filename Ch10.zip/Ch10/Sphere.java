
// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Shui
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
public class Sphere extends Object3D {
	private double radius;

	public Sphere(String _name, Object3D.Material _matType,double _radius) {
		super(_name, _matType);
		this.radius = _radius;
		// TODO Auto-generated constructor stub
	}
	public double getRadius() {
		return this.radius;
	}
	
	public double getVolume() {
		return 4.0/3.0*PI*(radius*radius*radius);
	}	//Calculate and return the volume of this object
	public double getSurface() {
		return 4.0*PI*(radius*radius);
		
	} //Calculate and return the surface area of this object

}
