
public class Square extends Shape2D implements Printable {
	private double side;

	public Square(String name,  double side) {
		super(name);
		this.side = side;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printinfo() {
		System.out.println("Square: "+ name+", Side: "+side+", Area: "+ getArea());
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getlabel() {
		// TODO Auto-generated method stub
		return "SQ-"+name;
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return side*side;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return side*4	;
	}
	
	public double getCompactness() {
        return getArea() / getPerimeter();
    }

    // 🔥 NEW: เชื่อม 2D → 3D
    public Cube toCube(Object3D.Material mat) {
        return new Cube(name + "_Cube", mat, side);
    }
	
	

}
