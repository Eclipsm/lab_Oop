// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Shui
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
public class WaxDie extends Cube implements Comparable<Object3D>,Meltable{
	public WaxDie(String _name, double _edge) {
		super(_name, Material.Wax, _edge);
	}
	
	@Override
	public int compareTo(Object3D o) {
		double diff = this.getVolume() - o.getVolume();
        if (diff != 0)
            return (int) Math.signum(diff);
        return this.getName().compareTo(o.getName());
		
		
		// TODO Auto-generated method stub
	}

	@Override
	public Object3D convertToOtherShape() {
		// TODO Auto-generated method stub
		double r = Math.cbrt(this.getVolume() * 3.0 / (4.0 * Object3D.PI));
		return new Sphere(this.getName(),this.getMaterial(),r);
	}

	

}
