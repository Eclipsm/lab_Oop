
public class Chips extends SnackBar {
private String flavor;
	
	public Chips(String name, double pricePerUnit,int weight ,String flavor) {
		super(name,pricePerUnit,weight);
		this.flavor = flavor;
	}
	public void printInfo() {
		System.out.println(name+","
				+ " price: "+getPricePerUnit()+" THB, "+"Flavor: "+ flavor);
	}

}
