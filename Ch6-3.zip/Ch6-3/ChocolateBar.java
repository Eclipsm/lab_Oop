
public class ChocolateBar extends SnackBar {
private boolean hasNut;
	
	public ChocolateBar(String name, double pricePerUnit,int weight ,boolean hasNut) {
		super(name,pricePerUnit,weight);
		this.hasNut = hasNut;
	}
	public void printInfo() {
		System.out.println(name+","
				+ " price: "+getPricePerUnit()+" THB, "+"Nut: "+ hasNut);
	}

}
