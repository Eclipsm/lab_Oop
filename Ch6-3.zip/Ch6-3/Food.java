// Template for Lab 6-2, this code should not be modified
// Author: Pisit.
public class Food {
    public String name;
    private int level;
    private double pricePerUnit;  // NEW: price

    public Food(String name, int level, double pricePerUnit) {
        this.name = name;
        this.level = level;
        this.pricePerUnit = pricePerUnit;
    }

    public void printInfo() {
        System.out.println(name + ": level " + level + ", price: " + pricePerUnit + " THB");
    }

    public int getLevel() {
        return level;
    }

    public double getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerCup(double pricePerCup) {
        this.pricePerUnit = pricePerUnit;
    }
}
