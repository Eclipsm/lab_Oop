/* Instruction: Make sure you read the comment properly and implement exactly what we asked…(Yes, this is a test). 
 *  You can modify parameters, variable name, access level, return type but not the method names in all classes we provided */

// File: FruitSmoothie
// Description: FruitSmoothie
// Assignment Number: 6
//
// ID: 6888047
// Name: Sila Klinsmith
// Section: 2
// Grader: //Piyapong
//
// On my honor, Sila Klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.

public class FruitSmoothie extends Food {
    private int caloryBlaBla; // Do something

    // Do something
    public FruitSmoothie(String name, int level,double pricePerUnit,int caloryBlaBla) {
        super(name, level, pricePerUnit);
        caloryBlaBla = 0;
    }

    @Override
    public void printInfo() {
        // TODO: print name, level, price, and calories
        // Example:
    	System.out.println(name+": level "+getLevel()+", price: "+getPricePerUnit()+" THB, "+"calories: "+caloryBlaBla);
        // Mango Smoothie: level 4, price: 55.0 THB, calories: 180
    }
}
