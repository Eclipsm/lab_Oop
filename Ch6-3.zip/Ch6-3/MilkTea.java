/* Instruction: Make sure you read the comment properly and implement exactly what we asked…(Yes, this is a test). 
 *  You can modify parameters, variable name, access level, return type but not the method names in all classes we provided */
// File: MilkTea
// Description: MilkTea
// Assignment Number: 6
//
// ID: 6888047
// Name: Sila Klinsmith
// Section: 2
// Grader: //Piyapong
//
// On my honor, Sila Klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.

public class MilkTea extends Food {
    private String topping;  // e.g., "boba", "grass jelly"

    public MilkTea(String name, int level, double pricePerUnit, String topping) {
        super(name, level, pricePerUnit);
        this.topping = topping;
        // Do something here
    }

    @Override
    public void printInfo() {
        // TODO: print name, level, price, and topping
        // Example:
        // Thai Milk Tea: level 3, price: 40.0 THB, topping: boba
    	System.out.println(name+": level "+getLevel()+", price: "+getPricePerUnit()+" THB, "+"topping: "+topping);
    }
}
