
public class ProteinBarSnack extends SnackBar {
	private int protienGram;
	
	public ProteinBarSnack(String name, double pricePerUnit,int weight ,int protienGram) {
		super(name,pricePerUnit,weight);
		this.protienGram = protienGram;
	}
	public void printInfo() {
		System.out.println(name+","
				+ " price: "+getPricePerUnit()+" THB, "+"Protein: "+ protienGram+" g");
	}

}
