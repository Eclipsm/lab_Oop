/* Instruction: Make sure you read the comment properly and implement exactly what we asked…(Yes, this is a test). 
 *  You can modify parameters, variable name, access level, return type but not the method names in all classes we provided */
// File: ProteinShake
// Description: ProteinShake
// Assignment Number: 6
//
// ID: 6888047
// Name: Sila Klinsmith
// Section: 2
// Grader: //Piyapong
//
// On my honor, Sila Klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.

// do something(s)...
public class ProteinShake extends Food{
    private int proteinGrams;

    public ProteinShake(String name, int level, double pricePerUnit,int proteinGrams) {
    	super(name, level, pricePerUnit);
        this.proteinGrams = proteinGrams;
    }

    @Override
    public void printInfo() {
        // TODO: print name, level, price, and protein content
        // Example:
        // Chocolate Shake: level 5, price: 65.0 THB, protein: 25g
    	System.out.println(name+": level "+getLevel()+", price: "+getPricePerUnit()+" THB, "+"protein: "+proteinGrams+" g");
    }
}
