

public class SnackBar extends Food {
	private int weight;
	
	public SnackBar(String name, double pricePerUnit, int weight) {
		super(name,0, pricePerUnit);
		this.weight = weight;
	}
	public void printInfo() {
		System.out.println(name+","
				+ " price: "+getPricePerUnit()+" THB, "+"Weight: "+weight+" g");
	}

}
