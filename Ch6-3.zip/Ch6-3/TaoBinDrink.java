/* Instruction: Make sure you read the comment properly and implement exactly what we asked…(Yes, this is a test). 
 *  You can modify parameters, variable name, access level, return type but not the method names in all classes we provided */
// File: TaoBinDrink
// Description: TaoBinDrink
// Assignment Number: 6
//
// ID: 6888047
// Name: Sila Klinsmith
// Section: 2
// Grader: //Piyapong
//
// On my honor, Sila Klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.

public class TaoBinDrink extends Food {
    private int sugarLevel;

    public TaoBinDrink(String name, int level, double pricePerUnit, int sugarLevel) {
        super(name, level, pricePerUnit);
        this.sugarLevel = sugarLevel;
    }

    public int getSugarLevel() {
        return sugarLevel;
    }

    // TODO: override printInfo()
    // Expected format example:
    // Iced Latte: level 3, price: 45.0 THB, sugar: 50
    // you can either override the original function completely or reuse the super method
    @Override
    public void printInfo() {
    	
    	System.out.println(name+": level "+getLevel()+", price: "+getPricePerUnit()+" THB, "+"sugar: "+sugarLevel);

    }
}
