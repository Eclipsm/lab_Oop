/* Instruction: Make sure you read the comment properly and implement exactly what we asked…(Yes, this is a test). 
 *  You can modify parameters, variable name, access level, return type but not the method names in all classes we provided */
// File: TaobinVendingMachine
// Description: TaobinVendingMachine
// Assignment Number: 6
//
// ID: 6888047
// Name: Sila Klinsmith
// Section: 2
// Grader: //Piyapong
//
// On my honor, Sila Klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.


import java.util.ArrayList;

public class TaoBinVendingMachine {
    private ArrayList<Food> menu;

    public TaoBinVendingMachine( ) {
        // Do something?
    	this.menu = new ArrayList<Food>();
    }
    
    public TaoBinVendingMachine(ArrayList<Food> menu) {
    	this.menu = menu;
    }

    // TODO 1: implement printMenu()
    // Example:
    // [0] Iced Latte - 45.0 THB
    // [1] Thai Milk Tea - 40.0 THB
    
    public void printMenu() {
    	System.out.println("=== FULL MENU ===");
    	
    	for(int i =0; i < menu.size(); i++ ) {
    		Food item = menu.get(i);
    		System.out.println("["+i+"] "+item.name+" - "+ item.getPricePerUnit()+" THB");
    		}
    	}
    
    public void printDrinkMenu() {
    	System.out.println("=== DRINK MENU ===");
    	
    	for(int i =0; i < menu.size(); i++ ) {
    		Food item = menu.get(i);
    		if(!(item instanceof SnackBar)) {
    		System.out.println("["+i+"] "+item.name+" - "+ item.getPricePerUnit()+" THB");
    		}
    	}

    }
    
    public void printSnackMenu() {
    	System.out.println("=== SNACK MENU ===");
    	
    	for(int i =0; i < menu.size(); i++ ) {
    		Food item = menu.get(i);
    		if(item instanceof SnackBar) {
    		System.out.println("["+i+"] "+item.name+" - "+ item.getPricePerUnit()+" THB");
    		}
    	}

    }

    // TODO 2: implement selectItem(int index)
    // If valid:
    //   print "Selected:" then call menu.get(index).printInfo()
    // Else:
    //   print "Invalid selection"
    public void selectItem(int index) {
            if(index >= 0 && index< menu.size()) {
            	System.out.println("Selected:");
            	 menu.get(index).printInfo();
            }else System.out.println("Invalid selection");
    }
}

