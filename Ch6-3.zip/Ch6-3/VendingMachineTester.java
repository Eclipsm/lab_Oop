/*
 *  This is the main testing class ,you should not modify it 
 *  */
import java.util.Scanner;
import java.util.ArrayList;

public class VendingMachineTester {
    public static void main(String[] args) {

        ArrayList<Food> menu = new ArrayList<>();

        menu.add(new TaoBinDrink("Iced Latte",        3, 45.0, 50));
        menu.add(new MilkTea("Thai Milk Tea",         3, 40.0, "boba"));
        menu.add(new FruitSmoothie("Mango Smoothie",  4, 55.0, 180));
        menu.add(new ProteinShake("Chocolate Shake",  5, 65.0, 25));
        
     // Snacks
        menu.add(new ChocolateBar("Snickers", 25.0, 40, true));
        menu.add(new ProteinBarSnack("FitBar", 30.0, 50, 20));
        menu.add(new Chips("Lays", 20.0, 30, "BBQ"));

        TaoBinVendingMachine machine = new TaoBinVendingMachine(menu);

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Show Drink Menu");
            System.out.println("2. Show Snack Menu");
            System.out.println("3. Show Full Menu");
            System.out.println("4. Select Item");
            System.out.println("5. Exit");
            System.out.print("Choose: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    machine.printDrinkMenu();
                    break;
                case 2:
                    machine.printSnackMenu();
                    break;
                case 3:
                    machine.printMenu();
                    break;
                case 4:
                	machine.printMenu();
                    System.out.print("Enter index: ");
                    int index = sc.nextInt();
                    machine.selectItem(index);
                    break;
                case 5:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 5);

        sc.close();
    }
}
