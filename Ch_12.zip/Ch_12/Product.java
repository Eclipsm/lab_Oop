/**
 * Product class representing a single product in stock.
 * This is the same Product class from Task 1.
 *
 * NOTE: Gson maps JSON keys directly to field names.
 *       Field names must match the JSON keys exactly.
 *
 * TODO: Fill in the constructor, getters, and setters below.
 */
public class Product {

    private String productId;
    private String name;
    private int quantity;
    private double price;

    /**
     * Constructor - assign each parameter to the matching field.
     *
     * TODO: Fill in the body
     */
    public Product(String productId, String name, int quantity, double price) {
        // TODO: assign parameters to fields
    	this.productId = productId;
    	this.name = name;
    	this.quantity = quantity;
    	this.price = price;
    }

    // --- Getters ---

    public String getProductId() {
        // TODO: return productId
        return productId;
    }

    public String getName() {
        // TODO: return name
        return name;
    }

    public int getQuantity() {
        // TODO: return quantity
        return quantity;
    }

    public double getPrice() {
        // TODO: return price
        return price;
    }

    // --- Setters ---

    public void setProductId(String productId) {
        // TODO: assign productId
    	this.productId = productId;
    }

    public void setName(String name) {
        // TODO: assign name
    	this.name = name;
    }

    public void setQuantity(int quantity) {
        // TODO: assign quantity
    	this.quantity = quantity;
    }

    public void setPrice(double price) {
        // TODO: assign price
    	this.price = price;
    }

    @Override
    public String toString() {
        return String.format("%-8s %-20s %5d %8.2f", productId, name, quantity, price);
    }
}

