import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Reads product stock data from a JSON file using Gson.
 */
public class StockJSONReader {

    /**
     * Reads stock.json and returns a list of Product objects.
     *
     * TODO:
     * 1. Create a Gson instance
     * 2. Open the JSON file using FileReader
     * 3. Define the type for ArrayList<Product> using TypeToken:
     *      Type listType = new TypeToken<ArrayList<Product>>(){}.getType();
     * 4. Use gson.fromJson(reader, listType) to deserialize
     * 5. Close the reader
     * 6. Return the list (return empty list if file not found)
     *
     * @param filename path to the JSON file
     * @return ArrayList of Product objects
     */
    public static ArrayList<Product> loadStock(String filename) {
        ArrayList<Product> stockList = new ArrayList<>();

        // TODO: Implement JSON reading here
        Gson gson = new Gson(); 
        FileReader reader = null; 
        try { 
        reader = new FileReader(filename); 
        Type listType = new TypeToken<ArrayList<Product>>(){}.getType(); 
        stockList = gson.fromJson(reader, listType); 
        } catch (IOException e) { 
        	e.printStackTrace();
        } finally { 
        	if (reader != null) { 
        		try { reader.close(); } 
        		catch (IOException e) { e.printStackTrace(); } 
        		} 
        		}


        return stockList;
    }
}
