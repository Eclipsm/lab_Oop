import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Writes product stock data to a JSON file using Gson.
 */
public class StockJSONWriter {

    /**
     * Saves the current stock list to stock.json, overwriting existing content.
     *
     * TODO:
     * 1. Create a Gson instance with pretty printing:
     *      Gson gson = new GsonBuilder().setPrettyPrinting().create();
     * 2. Convert stockList to JSON string: gson.toJson(stockList)
     * 3. Write the JSON string to the file using FileWriter
     * 4. Close the writer
     *
     * @param filename  path to the output JSON file
     * @param stockList current list of products
     */
    public static void saveStock(String filename, ArrayList<Product> stockList) {
        FileWriter writer = null;
        try {
            // TODO: Create Gson with pretty printing
             Gson gson = new GsonBuilder().setPrettyPrinting().create();

            // TODO: Convert list to JSON string
             String json = gson.toJson(stockList);

            // TODO: Write JSON string to file
             writer = new FileWriter(filename);
             writer.write(json);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try { writer.close(); } catch (IOException e) { e.printStackTrace(); }
            }
        }
    }
}
