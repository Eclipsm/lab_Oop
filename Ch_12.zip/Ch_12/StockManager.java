import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Main class for Task 2 - JSON Stock Management.
 * Same stock management as Task 1, but uses JSON instead of CSV.
 *
 * NOTE: The menu loop, deductStock, removeProduct, and displayStock
 *       are already implemented for you.
 *       Your job is to complete: Product.java, StockJSONReader.java, StockJSONWriter.java,
 *       and the two regex patterns below (OFFICER_PATTERN and SAVE_PASSWORD_PATTERN).
 */
public class StockManager {

    static final String STOCK_FILE = "stock.json";

    // ============================================================
    // TODO: Fill in the TWO regex patterns below
    // ============================================================

    // Pattern 1: Officer login
    // Format: "Firstname Lastname UIDddddd"
    // - Firstname: starts with uppercase, followed by lowercase letters (2-30 chars)
    // - Lastname:  starts with uppercase, followed by lowercase letters (2-30 chars)
    // - UID:       literal "UID" followed by exactly 5 digits
    // Example valid: "Somchai Jaidee UID12345"
    //
    // TODO: Replace with correct regex
    static final String OFFICER_PATTERN = "[A-Z][a-z]{1,29} [A-Z][a-z]{1,29} UID[0-9]{5}";

    // Pattern 2: Save password confirmation
    // Format: "StringKeywordDDMMYYYY"
    // - String:    the literal text "Save"
    // - Keyword:   one uppercase letter followed by lowercase letters (2-20 chars)
    // - DD:        exactly 2 digits (day)
    // - MM:        exactly 2 digits (month)
    // - YYYY:      exactly 4 digits (year)
    // Example valid: "SaveStock01042026"
    // Example valid: "SaveBackup31122025"
    //
    // TODO: Replace with correct regex
    static final String SAVE_PASSWORD_PATTERN = "Save[A-Z][a-z]{1,19}[0-9]{2}[0-9]{2}[0-9]{4}";

    // ============================================================
    // Validation methods (already implemented - do not modify)
    // ============================================================

    /**
     * Validates the officer login input against OFFICER_PATTERN.
     */
    public static boolean validateOfficer(String input) {
        if (!Pattern.matches(OFFICER_PATTERN, input)) {
            System.out.println("Invalid format: '" + input + "'");
            System.out.println("Please use: Firstname Lastname UIDddddd");
            return false;
        }
        return true;
    }

    /**
     * Validates the save password against SAVE_PASSWORD_PATTERN.
     */
    public static boolean validateSavePassword(String input) {
        if (!Pattern.matches(SAVE_PASSWORD_PATTERN, input)) {
            System.out.println("Invalid save password: '" + input + "'");
            System.out.println("Please use format: SaveKeywordDDMMYYYY (e.g. SaveStock01042026)");
            return false;
        }
        return true;
    }

    /**
     * Prompts for save password and saves stock if valid.
     * Returns true if saved successfully.
     */
    public static boolean confirmAndSave(ArrayList<Product> stockList, Scanner scanner) {
        System.out.print("Enter save password to confirm: ");
        String password = scanner.nextLine().trim();
        if (validateSavePassword(password)) {
            StockJSONWriter.saveStock(STOCK_FILE, stockList);
            System.out.println("Stock saved to " + STOCK_FILE);
            return true;
        } else {
            System.out.println("Save cancelled. Changes are in memory only.");
            return false;
        }
    }

    // ============================================================
    // Provided methods (do not modify below this line)
    // ============================================================

    /**
     * Displays all products in a formatted table.
     */
    public static void displayStock(ArrayList<Product> stockList) {
        System.out.println("\n=== Current Stock ===");
        System.out.printf("%-8s %-20s %5s %8s%n", "ID", "Name", "Qty", "Price");
        System.out.println("----------------------------------------------");
        for (Product p : stockList) {
            System.out.printf("%-8s %-20s %5d %8.2f%n",
                    p.getProductId(), p.getName(),
                    p.getQuantity(), p.getPrice());
        }
        System.out.println();
    }

    /**
     * Deducts the given quantity from the product matching productId.
     */
    public static boolean deductStock(ArrayList<Product> stockList, String productId, int qty) {
        for (Product p : stockList) {
            if (p.getProductId().equalsIgnoreCase(productId)) {
                if (qty > p.getQuantity()) {
                    System.out.println("Error: Not enough stock. Available: " + p.getQuantity());
                    return false;
                }
                p.setQuantity(p.getQuantity() - qty);
                System.out.println("Success: Sold " + qty + " x " + p.getName()
                        + ". Remaining: " + p.getQuantity());
                return true;
            }
        }
        System.out.println("Error: Product ID '" + productId + "' not found.");
        return false;
    }

    /**
     * Removes the product matching productId entirely from the list.
     */
    public static boolean removeProduct(ArrayList<Product> stockList, String productId) {
        for (int i = 0; i < stockList.size(); i++) {
            if (stockList.get(i).getProductId().equalsIgnoreCase(productId)) {
                Product removed = stockList.remove(i);
                System.out.println("Success: Removed product '" + removed.getName() + "' from stock.");
                return true;
            }
        }
        System.out.println("Error: Product ID '" + productId + "' not found.");
        return false;
    }

    /**
     * Main menu loop.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- Officer Login ---
        System.out.println("=== Officer Login ===");
        System.out.println("Format: Firstname Lastname UIDddddd");
        System.out.println("Example: Somchai Jaidee UID12345");
        while (true) {
            System.out.print("Enter officer ID: ");
            String officerInput = scanner.nextLine().trim();
            if (validateOfficer(officerInput)) {
                System.out.println("Welcome, " + officerInput + "!\n");
                break;
            }
        }

        // Load stock from JSON
        ArrayList<Product> stockList = StockJSONReader.loadStock(STOCK_FILE);

        if (stockList.isEmpty()) {
            System.out.println("Warning: No products loaded. Check stock.json and StockJSONReader.");
        }

        boolean running = true;
        while (running) {
            System.out.println("=== Stock Manager (JSON) ===");
            System.out.println("1. View Stock");
            System.out.println("2. Sell Item (deduct)");
            System.out.println("3. Remove Product");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    displayStock(stockList);
                    break;

                case "2":
                    System.out.print("Enter Product ID: ");
                    String sellId = scanner.nextLine().trim();
                    System.out.print("Enter quantity to sell: ");
                    try {
                        int qty = Integer.parseInt(scanner.nextLine().trim());
                        if (deductStock(stockList, sellId, qty)) {
                            confirmAndSave(stockList, scanner);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Error: Please enter a valid number.");
                    }
                    System.out.println();
                    break;

                case "3":
                    System.out.print("Enter Product ID to remove: ");
                    String removeId = scanner.nextLine().trim();
                    if (removeProduct(stockList, removeId)) {
                        confirmAndSave(stockList, scanner);
                    }
                    System.out.println();
                    break;

                case "4":
                    System.out.println("Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1-4.\n");
                    break;
            }
        }

        scanner.close();
    }
}
