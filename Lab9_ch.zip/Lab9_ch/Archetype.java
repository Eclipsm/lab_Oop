/**
 * Abstract base class for all character archetypes.
 * Defines the shared structure and contract that all archetypes must implement.
 *
 * Key OOP Concepts:
 * - Abstract class: cannot be instantiated directly
 * - Abstract methods: subclasses MUST override these
 * - Encapsulation: protected fields accessible to subclasses
 * - Polymorphism: different archetypes respond differently to the same method call
 * 
 * =======================================================================================
 * Pisit's Note: This class was completed and you should not modify them.
 * =======================================================================================
 */
public abstract class Archetype {

    protected String archetypeName;
    protected int maxHealth;
    protected int currentHealth;
    protected int attackPower;
    protected int defensePower;

    /**
     * Constructor for all archetypes.
     * @param archetypeName display name of this archetype (e.g., "Mage", "Fighter")
     * @param maxHealth     maximum hit points
     * @param attackPower   base attack damage
     * @param defensePower  base defense value
     */
    public Archetype(String archetypeName, int maxHealth, int attackPower, int defensePower) {
        this.archetypeName = archetypeName;
        this.maxHealth = maxHealth;
        this.currentHealth = maxHealth;
        this.attackPower = attackPower;
        this.defensePower = defensePower;
    }

    /**
     * Primary action (usually a basic attack).
     * @param target the archetype being targeted
     * @return a description of what happened
     */
    public abstract String doAction1(Archetype target);

    /**
     * Secondary/special action (class-specific ability).
     * @param target the archetype being targeted (may be ignored for self-buffs)
     * @return a description of what happened
     */
    public abstract String doAction2(Archetype target);

    /**
     * Defensive action - reduces or negates incoming damage.
     * @param incomingDamage the raw damage before defense
     * @return the actual damage taken after defense
     */
    public abstract int doDefense(int incomingDamage);

    /**
     * Called at the start of each turn for resource regeneration or cooldown ticks.
     */
    public abstract void onTurnStart();

    /**
     * Returns a string showing the archetype's unique resource status.
     * @return resource status string (e.g., "MP: 30/50")
     */
    public abstract String getResourceStatus();

    /**
     * Apply damage to this archetype. Health cannot go below 0.
     * @param damage amount of damage to apply
     */
    public void takeDamage(int damage) {
        this.currentHealth = Math.max(0, this.currentHealth - damage);
    }

    /**
     * Heal this archetype. Health cannot exceed maxHealth.
     * @param amount amount of health to restore
     */
    public void heal(int amount) {
        this.currentHealth = Math.min(maxHealth, this.currentHealth + amount);
    }

    /**
     * Check if this archetype is still alive.
     * @return true if currentHealth > 0
     */
    public boolean isAlive() {
        return currentHealth > 0;
    }
    public void boostAttack(int amount) {
    	this.attackPower += amount;
    }
    
    public void boostDefense(int amount) {
    	this.defensePower += amount;
    }

    // --- Getters ---
    public String getArchetypeName() { return archetypeName; }
    public int getMaxHealth()        { return maxHealth; }
    public int getCurrentHealth()    { return currentHealth; }
    public int getAttackPower()      { return attackPower; }
    public int getDefensePower()     { return defensePower; }

    @Override
    public String toString() {
        return archetypeName + " [HP: " + currentHealth + "/" + maxHealth + " | " + getResourceStatus() + "]";
    }
}
