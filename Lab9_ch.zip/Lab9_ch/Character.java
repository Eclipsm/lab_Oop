
/**
 * TODO: Implement the Generic Character class.
 *
 * This is the KEY class of this lab!
 *
 * Character<T extends Archetype> means:
 * - T can be Mage, Fighter, Thief, or any future Archetype subclass
 * - The compiler ensures type safety at compile time
 * - getArchetype() returns T (the specific type), NOT just Archetype
 *
 * Example usage:
 *   Character<Mage> c1 = new Character<>("Alice", 70, 4, 24, new Mage());
 *   Mage m = c1.getArchetype();  // No cast needed! Returns Mage directly.
 *   m.getCurrentMP();             // Can access Mage-specific methods.
 *
 * Instructions:
 * 1. Make sure the class declaration uses <T extends Archetype>
 * 2. Store the archetype as type T (not Archetype)
 * 3. getArchetype() must return T
 * 4. Action methods should accept Character<? extends Archetype> as target
 *    (wildcard generic - accepts any character regardless of archetype)
 *
 * @param <T> the archetype type, must extend Archetype
 */
// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Earn
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
public class Character<T extends Archetype> {
	private String name;
	private T archetype;
	private Inventory<T> inventory;

    // TODO: Declare private fields
    //   - name (String)
    //   - archetype (T)  <-- NOTE: type is T, not Archetype

    /**
     * TODO: Implement constructor
     *
     * @param name      the character's display name
     * @param health    max hit points
     * @param defense   defense power
     * @param attack    attack power
     * @param archetype the archetype instance (type T)
     */
    public Character(String name, int health, int defense, int attack, T archetype) {
        // TODO: Initialize fields
    	this.name = name;
    	this.archetype = archetype;
    	this.inventory = new Inventory<>();
    	
    	// Pisit's Note: Fighter, Mage, Theif has default constructor
    	// In example output, I simplified version, the archetype's own stats are used instead of our inputs here
        // You may modify The constructor parameters allow customization if desired.
    }

    /**
     * TODO: Execute primary action against a target.
     *
     * Note the wildcard generic parameter:
     *   Character<? extends Archetype> target
     * This means this method accepts ANY Character, regardless of its archetype type.
     *
     * Steps:
     * 1. Call archetype.doAction1(target.getArchetype())
     * 2. Return the result string
     */
    public String performAction1(Character<? extends Archetype> target) {
        // Example: Delegate to archetype's doAction1
    	// Pisit's Note: This task was completed and served as an example for you.
    	return archetype.doAction1(target.getArchetype());
    }

    /**
     * TODO: Execute secondary action against a target.
     *
     * Steps:
     * 1. Call archetype.doAction2(target.getArchetype())
     * 2. Return the result string
     */
    public String performAction2(Character<? extends Archetype> target) {
        // TODO: Delegate to archetype's doAction2
        return archetype.doAction2(target.getArchetype()); // placeholder
    }

    /**
     * TODO: Execute defense against incoming damage.
     */
    public int performDefense(int incomingDamage) {
        // TODO: Delegate to archetype's doDefense
    	// Pisit's Note: archetype have doDefense( ) for damage received, utilize it
        return archetype.doDefense(incomingDamage); // placeholder
    }

    /**
     * TODO: Called at start of each turn.
     * Delegate to archetype's onTurnStart().
     */
    public void startTurn() {
    	archetype.onTurnStart();
        // TODO: Call archetype.onTurnStart()
    }

    /**
     * TODO: Check if character is alive.
     * Delegate to archetype's isAlive().
     */
    public boolean isAlive() {
        // TODO: Delegate to archetype.isAlive()
        return archetype.isAlive(); // placeholder
    }
    public String useItem(int index) {
        return inventory.useItem(index, archetype);
    }
    public String useNextItem() {
        return inventory.useNextItem(archetype);
    }

    /**
     * TODO: Return the archetype.
     * IMPORTANT: Return type is T, not Archetype!
     * This is what enables: Character<Mage>.getArchetype() -> returns Mage
     */
    public Inventory<T> getInventory() { 
    	return inventory; 
    	}
    public T getArchetype() {
        // TODO: Return the archetype field
        return archetype; // placeholder
    }

    public String getName() {
        // TODO: Return the name field
        return name; // placeholder
    }

    /**
     * TODO: Return a formatted status string.
     * Example: "Alice the Mage [HP: 60/60 | MP: 50/50]"
     * Pisit's Ntoe: Get a formatted status string showing name, archetype, HP, and resources* of the class.
     * archetype.getArchetypeName()
     * archetype.getCurrentHealth()
     * archetype.getResourceStatus()
     * follow my example format carefully
     */
    public String getStatus() {
        // TODO: Build and return status string using archetype methods
        return name+" the " + archetype.getArchetypeName()
        + " [HP: "    + archetype.getCurrentHealth() + "/" + archetype.getMaxHealth()
        + " | ATK: "  + archetype.getAttackPower()
        + " | DEF: "  + archetype.getDefensePower()
        + " | "       + archetype.getResourceStatus()
        + " | Items: " + inventory.getSize() + "/" + inventory.getMaxSize() + "]";
    }

    @Override
    public String toString() {
        return getStatus();
    }
}
