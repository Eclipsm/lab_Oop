
public class DefensePotion extends Item<Archetype> {
	private int boostAmount;
	public DefensePotion(int boostAmount) {
		super("Defense Potion","Increases defense by + "+ boostAmount + " permanently");
		this.boostAmount = boostAmount;
	}
	public String useItem(Archetype target) {
		int oldDef = target.getDefensePower();
		target.boostDefense(boostAmount);
		return target.getArchetypeName()+" drinks Defense Potion! Defense boosted from "+
		 oldDef +" to "+ target.getDefensePower()+" permanently!";
	}

}
