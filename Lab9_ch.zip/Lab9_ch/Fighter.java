
/**
 * TODO: Implement the Fighter archetype.
 *
 * Fighter Characteristics:
 * - High HP: 120
 * - High Defense: 8
 * - Moderate Attack: 15 (base) with 1.6x bash multiplier
 * - Unique resource: Stamina, max 40
 * - Stamina regenerates 4 per turn passively (no active recharge needed)
 *
 * Actions to implement:
 * - doAction1: Normal Strike -> free attack, deals attackPower damage
 * - doAction2: Bash -> costs 12 stamina, deals attackPower * 1.6 damage
 *   (if not enough stamina, return a failure message)
 * - doDefense: Guard -> reduces incoming damage by defensePower (8)
 * - onTurnStart: Regenerate 4 stamina (up to max)
 * - getResourceStatus: return "STA: currentStamina/maxStamina"
 *
 * Instructions:
 * 1. This class must extend Archetype
 * 2. Call super() with the correct stats: ("Fighter", 120, 15, 8)
 * 3. Add private fields for Stamina management
 * 4. Implement all abstract methods from Archetype
 * Earn

// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Earn
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
 */
public class Fighter extends Archetype {

    // TODO: Declare private fields for Fighter's unique resource
       private int maxStamina  = 40;
       private int currentStamina  = 40;
       private int staminaRegenPerTurn  = 4;
       private int bashCost  = 12;
       private double bashMultiplier = 1.6;

    /**
     * TODO: Constructor - call super() with Fighter stats
     * Stats: name="Fighter", maxHealth=120, attackPower=15, defensePower=8
     * Also initialize all Stamina-related fields.
     */
    public Fighter() {
        super("Fighter", 120, 15, 8);
        // TODO: Initialize Stamina fields
    }

    /**
     * TODO: Implement Normal Strike
     *
     * Steps:
     * 1. Calculate damage = attackPower (no multiplier, no cost)
     * 2. Apply target's defense: actualDamage = target.doDefense(damage)
     * 3. Apply damage: target.takeDamage(actualDamage)
     * 4. Return a description string
     */
    @Override
    public String doAction1(Archetype target) {
    	int damage = attackPower;
    	int actualDamage = target.doDefense(damage);
    	target.takeDamage(actualDamage);
        // TODO: Implement normal strike
        return "Fighter strikes with sword! Deals "+ actualDamage+" damage."; // placeholder
    }

    /**
     * TODO: Implement Bash
     *
     * Steps:
     * 1. Check if currentStamina >= bashCost
     *    - If not enough stamina, return failure message
     * 2. Subtract bashCost from currentStamina
     * 3. Calculate damage = (int)(attackPower * bashMultiplier)
     * 4. Apply target's defense: actualDamage = target.doDefense(damage)
     * 5. Apply damage: target.takeDamage(actualDamage)
     * 6. Return a description string
     */
    @Override
    public String doAction2(Archetype target) {
    	if(currentStamina < bashCost) {
    		return ("Bash fail! Not enough Stamina ("+currentStamina+"/"+bashCost+"needed"+")");
    	}
    	currentStamina -=bashCost;
    	int damage = (int)(attackPower*bashMultiplier);
    	int actualDamage = Math.max(0, damage-defensePower);
    	target.takeDamage(actualDamage);
        // TODO: Implement bash attack
        return "Fighter performs a powerful BASH! Deals "+actualDamage+" damage."; // placeholder
    }

    /**
     * TODO: Implement Guard defense
     *
     * Formula: actualDamage = max(0, incomingDamage - defensePower)
     * @return the actual damage after defense reduction
     */
    @Override
    public int doDefense(int incomingDamage) {
        // TODO: Calculate and return reduced damage
        return Math.max(0, incomingDamage - defensePower); // placeholder - takes full damage
    }

    /**
     * TODO: Implement passive stamina regeneration
     *
     * Steps:
     * 1. Save oldStamina = currentStamina
     * 2. Add staminaRegenPerTurn to currentStamina (cap at maxStamina)
     * 3. Print a message showing how much stamina was recovered
     */
    @Override
    public void onTurnStart() {
    	int oldStamina = currentStamina;
    	currentStamina += staminaRegenPerTurn ;
    	if(currentStamina > maxStamina) {
    		currentStamina = maxStamina;
    	}
    	int recovered = currentStamina - oldStamina;
    	if(recovered>0) {
    		System.out.println(" Fighter recovers "+recovered+" stamina. "+"(Stamina: "+ currentStamina+"/"+maxStamina+")");
    	}
        // TODO: Regenerate stamina passively each turn
    }

    @Override
    public String getResourceStatus() {
        // TODO: Return "STA: currentStamina/maxStamina"
        return "STA: "+ currentStamina+"/"+maxStamina; // placeholder
    }

    // TODO: Add Fighter-specific getters
    //   - getCurrentStamina()
    public int getCurrentStamina() {
    	return currentStamina;
    }
    public int getMaxStamina() {
    	return maxStamina;
    }
    //   - getMaxStamina()
}
