
public class HealthPotion extends Item<Archetype> {
	private int healAmount;
	public HealthPotion(int healAmount) {
		super("Health Potion", "Restores "+healAmount+ "HP");
		this.healAmount =healAmount;
	}
	
	public String useItem(Archetype target) {
		int oldHP = target.currentHealth;
		target.heal(healAmount);
		int restored =target.getCurrentHealth()-oldHP;
		return target.getArchetypeName()+ " drinks Health Potion! Restored "+
				restored+ " HP. (HP: "+ target.getCurrentHealth()+"/"+ target.getMaxHealth()+")";
	}
}
