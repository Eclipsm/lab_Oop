import java.util.ArrayList;

public class Inventory<T extends Archetype> {
	
	private static final int MAX_SIZE =4;
	private ArrayList<Item<Archetype>> items;
	
	public Inventory() {
		this.items = new ArrayList<>();
	}
	public boolean addItem(Item<Archetype> item) {
		if(isFull()) {
			System.out.println("Inventory is full! Cannot add " + item.getName() + ".");
            return false;
		}
		items.add(item);
		return true;
	}
	
	public String useItem(int index, T target) {
		if(isEmpty()) {
			return"Inventory is empty! No items to use.";
		}
		 if (index < 0 || index >= items.size()) {
	            return "Invalid item index " + index + ". Inventory has " + items.size() + " item(s).";
		 }
		 Item<Archetype> item = items.remove(index);
		 return item.useItem(target);
	}
	public Item<Archetype> getItem(int index) {
        if (index < 0 || index >= items.size()) return null;
        return items.get(index);
    }
    public String useNextItem(T target) {
        if (isEmpty()) {
            return "No items left to use!";
        }
        Item<Archetype> item = items.remove(0);
        return item.useItem(target);
    }
	
	public void displayInventory() {
        System.out.println("  Inventory (" + getSize() + "/" + MAX_SIZE + "):");
        if (isEmpty()) {
            System.out.println("    (empty)");
            return;
        }
        for (int i = 0; i < items.size(); i++) {
            System.out.println("    [" + i + "] " + items.get(i));
        }
    }
	
	
	  public int     getSize()    { 
		  return items.size(); }
	  public int     getMaxSize() { 
		  return MAX_SIZE; }
	  public boolean isEmpty()    { 
		  return items.isEmpty(); }
	  public boolean isFull()     { 
		  return items.size() >= MAX_SIZE; }

}
