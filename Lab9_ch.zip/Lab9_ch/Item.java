
public abstract class Item <T extends Archetype>  {
	protected String name;
	protected String description;
	
	public Item(String name, String description) {
		this.name = name;
		this.description = description;
	}
	
	public abstract String useItem(T target);
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public String toString() {
		return name+" - "+description;
	}

}
