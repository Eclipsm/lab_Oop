/**
 * TODO: Implement the Mage archetype.
 *
 * Mage Characteristics:
 * - Low HP: 60
 * - Low Defense: 3
 * - High Attack: 25 (base) with 1.8x magic multiplier
 * - Unique resource: MP (Mana Points), max 50
 *
 * Actions to implement:
 * - doAction1: Magic Attack -> costs 15 MP, deals attackPower * 1.8 damage
 *   (if not enough MP, return a failure message)
 * - doAction2: Charge MP -> recovers 20 MP (up to max)
 *   (target parameter is ignored - this is a self-buff)
 * - doDefense: Weak guard -> reduces incoming damage by defensePower (3)
 * - onTurnStart: Mage has no passive regeneration (leave empty)
 * - getResourceStatus: return "MP: currentMP/maxMP"
 *
 * Instructions:
 * 1. This class must extend Archetype
 * 2. Call super() with the correct stats: ("Mage", 60, 25, 3)
 * 3. Add private fields for MP management
 * 4. Implement all abstract methods from Archetype
 */
// ID: 6888047
// Name: Sila klinsmith
// Section: 2
// Grader: Earn
//
// On my honor, Sila klinsmith, this lab assignment is my own work
// and I have not provided this code to any other students.
public class Mage extends Archetype {

    // TODO: Declare private fields for Mage's unique resource
    //   - maxMP (int) = 50
    //   - currentMP (int) = 50
    //   - mpCostPerAttack (int) = 15
    //   - magicMultiplier (double) = 1.8
    //   - mpChargeAmount (int) = 20
	private int maxMP = 50;
	private int currentMP =50;
	private int mpCostPerAttack =15;
	private double magicMultiplier =1.8;
	private int mpChargeAmount = 20;

    /**
     * TODO: Constructor - call super() with Mage stats
     * Stats: name="Mage", maxHealth=60, attackPower=25, defensePower=3
     * Also initialize all MP-related fields.
     */
    public Mage() {
        super("Mage", 60, 25, 3);
        // TODO: Initialize MP fields
    }

    /**
     * TODO: Implement Magic Attack
     *
     * Steps:
     * 1. Check if currentMP >= mpCostPerAttack
     *    - If not enough MP, return failure message
     * 2. Subtract mpCostPerAttack from currentMP
     * 3. Calculate damage = (int)(attackPower * magicMultiplier)
     * 4. Apply target's defense: actualDamage = target.doDefense(damage)
     * 5. Apply damage: target.takeDamage(actualDamage)
     * 6. Return a description string
     */
    @Override
    public String doAction1(Archetype target) {
    	if(currentMP < mpCostPerAttack) {
    		return ("Magic attack fail! Not enough MP ("+currentMP+"/"+mpCostPerAttack+"needed"+")");
    	}
    	currentMP -= mpCostPerAttack;
    	int damage = (int)(attackPower*magicMultiplier);
    	int actualDamage = target.doDefense(damage);
    	target.takeDamage(actualDamage);
        // TODO: Implement magic attack
        return "Mage casts Magic Attack! Deals "+ actualDamage+" damage. "+"MP used: "
        +mpCostPerAttack+" MP remaining: "+ currentMP+"/"+maxMP+")"; // placeholder
    }

    /**
     * TODO: Implement Charge MP
     *
     * Steps:
     * 1. Save oldMP = currentMP
     * 2. Add mpChargeAmount to currentMP (cap at maxMP)
     * 3. Calculate recovered = currentMP - oldMP
     * 4. Return a description string
     */
    @Override
    public String doAction2(Archetype target) {
    	int oldMp = currentMP;
    	currentMP += mpChargeAmount ;
    	if(currentMP > maxMP) {
    		currentMP = maxMP;
    	}
    	int recovered = currentMP - oldMp;
    	
        // TODO: Implement MP charging
        return "Mage charges magical energy! Recovered "+recovered+"MP.  (MP: "+currentMP+"/"+maxMP+")"; // placeholder
    }

    /**
     * TODO: Implement weak magical guard
     *
     * Formula: actualDamage = max(0, incomingDamage - defensePower)
     * @return the actual damage after defense reduction
     */
    @Override
    public int doDefense(int incomingDamage) {
        // TODO: Calculate and return reduced damage
        return Math.max(0, incomingDamage - defensePower); // placeholder - takes full damage
    }

    /**
     * Mage has no passive regeneration.
     */
    @Override
    public void onTurnStart() {
        // Mage does not regenerate passively - intentionally empty
    }

    @Override
    public String getResourceStatus() {
        // TODO: Return "MP: currentMP/maxMP"
        return "MP: "+ currentMP+"/"+maxMP; // placeholder
    }

    // TODO: Add Mage-specific getters
    //   - getCurrentMP()
    //   - getMaxMP()
    public int getCurrentMP() {
    	return currentMP;
    }
    public int getMaxMP() {
    	return maxMP;
    }
}
