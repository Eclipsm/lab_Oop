/**
 * Main class — Lab 9-2c: Inventory System
 * Antagonizer: Pisit Praiwattana
 * email: pisit.pra@mahidol.ac.th
 * 
 * Use this template to test your challenge code
 *
 * Demonstrates:
 * - Item<T extends Archetype> as a generic item class
 * - Inventory<T> using ArrayList with fixed capacity 4
 * - useItem(int index) to pick a specific item
 * - useNextItem() to grab the first available item
 * - Character<T> updated with inventory support
 * - Using items during a turn-based duel
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("==============================================");
        System.out.println("  GENERIC QUEST — Lab 9-2c: Inventory System");
        System.out.println("==============================================");
        System.out.println();

        // ─── Create Characters ───
        // Inventory has fixed capacity of 4 items
        Character<Mage>    c1 = new Character<>("Alice", 60, 3, 25, new Mage());
        Character<Fighter> c2 = new Character<>("Bob",   120, 8, 15, new Fighter());

        // ─── Give Items to Characters ───
        // Items work on Archetype (the base type), so they fit any character
        c1.getInventory().addItem(new HealthPotion(30));    // [0]
        c1.getInventory().addItem(new PowerPotion());       // [1]
        c1.getInventory().addItem(new DefensePotion(3));    // [2]
        c1.getInventory().addItem(new HealthPotion(20));    // [3]

        c2.getInventory().addItem(new HealthPotion(25));    // [0]
        c2.getInventory().addItem(new HealthPotion(25));    // [1]
        c2.getInventory().addItem(new PowerPotion());       // [2]
        c2.getInventory().addItem(new DefensePotion(5));    // [3]

        // ─── Show Starting State ───
        System.out.println("Starting Status:");
        System.out.println("  " + c1.getStatus());
        System.out.println("  " + c2.getStatus());
        System.out.println();

        System.out.println("Alice's Inventory:");
        c1.getInventory().displayInventory();
        System.out.println();

        System.out.println("Bob's Inventory:");
        c2.getInventory().displayInventory();
        System.out.println();

        // ─── Demonstrate Using Items Before Combat ───
        System.out.println("---------- Pre-Battle Item Use ----------");
        System.out.println();

        // Alice uses item [1] Power Potion (pick by index)
        System.out.println(c1.getName() + ": " + c1.useItem(1));
        System.out.println("  " + c1.getStatus());
        System.out.println();

        // Bob uses next item (grabs [0] Health Potion automatically)
        System.out.println(c2.getName() + ": " + c2.useNextItem());
        System.out.println("  " + c2.getStatus());
        System.out.println();

        System.out.println("After item use:");
        System.out.println("Alice's Inventory:");
        c1.getInventory().displayInventory();
        System.out.println("Bob's Inventory:");
        c2.getInventory().displayInventory();
        System.out.println();

        // ─── Turn-Based Duel with Item Use ───
        System.out.println("========== DUEL BEGIN ==========");
        System.out.println();

        int turnNumber = 1;

        while (c1.isAlive() && c2.isAlive()) {

            System.out.println("===== Turn " + turnNumber + " =====");
            c1.startTurn();
            c2.startTurn();

            int actionPhase = (turnNumber - 1) % 4;  // 0,1,2,3 cycle
            String result;

            // ─── Alice acts ───
            switch (actionPhase) {
                case 0:  // Attack
                    result = c1.performAction1(c2);
                    System.out.println(c1.getName() + ": " + result);
                    break;
                case 1:  // Special
                    result = c1.performAction2(c2);
                    System.out.println(c1.getName() + ": " + result);
                    break;
                case 2:  // Use next item (if available)
                    if (!c1.getInventory().isEmpty()) {
                        System.out.println(c1.getName() + ": " + c1.useNextItem());
                    } else {
                        result = c1.performAction1(c2);
                        System.out.println(c1.getName() + " (no items): " + result);
                    }
                    break;
                case 3:  // Defense turn
                    System.out.println(c1.getName() + ": takes a defensive stance.");
                    break;
            }

            if (!c2.isAlive()) {
                System.out.println("\n" + c2.getName() + " has been defeated!");
                break;
            }
            System.out.println("  " + c2.getStatus());
            System.out.println();

            // ─── Bob acts ───
            switch (actionPhase) {
                case 0:
                    result = c2.performAction1(c1);
                    System.out.println(c2.getName() + ": " + result);
                    break;
                case 1:
                    result = c2.performAction2(c1);
                    System.out.println(c2.getName() + ": " + result);
                    break;
                case 2:
                    if (!c2.getInventory().isEmpty()) {
                        System.out.println(c2.getName() + ": " + c2.useNextItem());
                    } else {
                        result = c2.performAction1(c1);
                        System.out.println(c2.getName() + " (no items): " + result);
                    }
                    break;
                case 3:
                    System.out.println(c2.getName() + ": takes a defensive stance.");
                    break;
            }

            if (!c1.isAlive()) {
                System.out.println("\n" + c1.getName() + " has been defeated!");
                break;
            }
            System.out.println("  " + c1.getStatus());
            System.out.println();

            turnNumber++;
        }

        // ─── Final Results ───
        System.out.println();
        System.out.println("==============================================");
        System.out.println("              DUEL RESULTS");
        System.out.println("==============================================");
        System.out.println("  " + c1.getStatus());
        System.out.println("  " + c2.getStatus());
        System.out.println();

        if (c1.isAlive() && !c2.isAlive()) {
            System.out.println("WINNER: " + c1.getName() + "!");
        } else if (!c1.isAlive() && c2.isAlive()) {
            System.out.println("WINNER: " + c2.getName() + "!");
        } else {
            System.out.println("Draw!");
        }
    }
}
