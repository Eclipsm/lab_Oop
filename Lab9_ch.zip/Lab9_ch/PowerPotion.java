
public class PowerPotion extends Item<Archetype>{
	public PowerPotion() {
		super("Power Potion","Increases attack power by 10% permanently");
		
	}
	public String useItem(Archetype target) {
		int oldAttack = target.getAttackPower();
		int boost = Math.max(1,(int)( oldAttack*0.10));
		target.boostAttack(boost);
		return target.getArchetypeName()+" drinks Power Potion! Attack boosted from "+
		oldAttack+" to " + target.getAttackPower()+" permanently!";
	}

}
